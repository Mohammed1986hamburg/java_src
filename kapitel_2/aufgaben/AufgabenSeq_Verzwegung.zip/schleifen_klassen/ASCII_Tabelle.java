package aufgaben_schleifen;

public class ASCII_Tabelle {
	
	public static void main(String [] args) {
		char zeichen ;
		
		for (int i = 1; i < 256; i++)
			if(i % 6 == 0) {
				zeichen = (char) (i);
				System.out.print(i+" = "+ zeichen +"\t");
				System.out.println();
				}
			else {
				zeichen = (char) (i);
				System.out.print(i+" = " + zeichen +"\t");
			}
	/*
	 * 9 = \\t
	 * 10 = \\n 
	 * 12 = \\f
	 * 13 = \\r*/
	}
}
