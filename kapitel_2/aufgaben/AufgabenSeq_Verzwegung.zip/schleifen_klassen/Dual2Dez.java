package aufgaben_schleifen;

import java.util.Scanner;

public class Dual2Dez {

	public static void main(String[] args) {
		int zahl = 0;
		int	hoch = 1;
		int dual = 0;
		Scanner eingabe = new Scanner(System.in);
		
		System.out.print("Bitte geben Sie die Dualzahl ein: ");
		dual = eingabe.nextInt();
		
		System.out.print("Die Dualzahl " + dual + " hat den Dezimalwert: ");
		while (dual != 0) {
			zahl = zahl + ((dual % 10) * hoch);
			dual = dual / 10;
			hoch = hoch * 2;
		}
		System.out.println(zahl);

	}

}
