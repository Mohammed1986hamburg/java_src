package aufgaben_schleifen;

import java.util.Scanner;

public class GeldAutomat {

	public static void main(String[] args) {
		
		int betrag;
		int fuenfh = 0;
		int zweih = 0;
		int einh = 0; 
		int fuenfz = 0;
		int zwanzig = 0;
		int zehn = 0;
		int fuenf = 0;
		boolean betragKorrekt ;
		
		Scanner eingabe = new Scanner(System.in);
		Eingabe:			// Label
		do {
			System.out.println("Bitte geben sie den auszuzahlenden Geldbetrag ein:");
			betrag = eingabe.nextInt();
			
			if (betrag % 5 != 0){
				System.out.println("Der Betrag muss durch 5 teilbar sein!");
				betragKorrekt = false;
				continue Eingabe;
			}else {
				betragKorrekt = true;
			}
			 	 
			while (betragKorrekt) {
		
				if (betrag < 5 || betrag > 1000){
					System.out .println("Es kann nur Geld zwischen 5 und 1000� abgehoben werden! ");
					betragKorrekt = false;
					continue Eingabe;
					
				} else {
					if (betrag >= 500){
						fuenfh = betrag / 500;
						betrag = betrag - (fuenfh * 500);
					}
					if (betrag >= 200){
						zweih = betrag / 200;
						betrag = betrag - (zweih * 200);
					}
					if (betrag >= 100){
						einh = betrag / 100;
						betrag = betrag - (einh * 100);
					}
					if (betrag >= 50){
						fuenfz = betrag / 50;
						betrag = betrag - (fuenfz * 50);
					}
					if (betrag >= 20){
						zwanzig = betrag / 20;
						betrag = betrag - (zwanzig * 20);
					}
					if (betrag >= 10){
						zehn = betrag / 10;
						betrag = betrag - (zehn * 10);
					}
					if (betrag >= 5){
						fuenf = betrag / 5;
						betrag = betrag - (fuenf * 5);
					}
				System.out.println(fuenfh + "*500 " + zweih + "*200 " + einh
						+ "*100 " + fuenfz + "*50 " + zwanzig + "*20 " + zehn
						+ "*10 " + fuenf + "*5");
				break;
			}
		}
	}while(!betragKorrekt);
	}

}
