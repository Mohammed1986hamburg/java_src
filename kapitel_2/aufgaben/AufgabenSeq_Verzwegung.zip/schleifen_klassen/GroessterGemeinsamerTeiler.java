package aufgaben_schleifen;

import java.util.Scanner;

public class GroessterGemeinsamerTeiler {

	public static void main(String[] args) {
		int wert1;
		int wert2;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Z�hler:");
		wert1 = scanner.nextInt();
		
		System.out.print("Nenner: ");
		wert2 = scanner.nextInt();
		
		while(wert1 > 0 && wert2 > 0) {
			if(wert1 > wert2) {
				wert1 = wert1 - wert2;
			}else {
				wert2 = wert2 - wert1;
			}
		}
		
		System.out.print("Der gr��te gemeinsame Teiler ist: ");
		
		if(wert2 == 0) {
			System.out.println(wert1);
		}else {
			System.out.println(wert2);
		}

	}

}
