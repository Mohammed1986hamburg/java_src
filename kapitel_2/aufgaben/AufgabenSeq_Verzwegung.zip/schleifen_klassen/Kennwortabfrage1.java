package aufgaben_schleifen;

import java.util.Scanner;

public class Kennwortabfrage1 {

	public static void main(String[] args) {
		
		String eingabe;
		String kennwort = "abc";
		
		Scanner sc = new Scanner(System.in);

		do{
			System.out.println("Kennwort: ");
			eingabe=sc.nextLine();
			if(!eingabe.equals(kennwort)) {
			System.out.println("Falsches Kennwort");
			}
		}while (!eingabe.equals(kennwort));
		
		System.out.println("Kennwort ist richtig");

	}

}
