package aufgaben_schleifen;

import java.util.Scanner;

public class Kennwortabfrage2 {

	public static void main(String[] args) {
	
		String 	eingabe;
		String 	kennwort = "abc";
		int 	anzahl = 1;
		
		Scanner sc = new Scanner(System.in);
		do{
			System.out.print("Kennwort: ");
			eingabe=sc.nextLine();
		
			if(eingabe.equals(kennwort)){
				System.out.println("Richtig, du hast " + anzahl +" Versuch(e) ben�tigt");
				break;
			}else {
				System.out.println(anzahl + ".) falsch");
			}
			anzahl++;
			
			if(anzahl==4){
				System.out.println("Zugriff verweigert!");
				break;
			}
		}while(true);

	}

}
