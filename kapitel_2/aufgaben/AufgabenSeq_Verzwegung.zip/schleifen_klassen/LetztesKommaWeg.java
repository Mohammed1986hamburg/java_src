package aufgaben_schleifen;

public class LetztesKommaWeg {

	public static void main(String[] args) {
		
		// Version 1
		System.out.println("------------- Version 1 ----------");
		for(int i = 1;i <= 10; i++) {
			if(i!=10) {
				System.out.print(i+", ");
			}else {
				System.out.print(i);
			}
		}
		
		// Version 2
		int i;
		System.out.println();
		System.out.println("------------- Version 2 ----------");
		for(i=1;i<10;i++) {
			System.out.print(i+", ");
		}
		
		System.out.print(i);
			
			

	}

}
