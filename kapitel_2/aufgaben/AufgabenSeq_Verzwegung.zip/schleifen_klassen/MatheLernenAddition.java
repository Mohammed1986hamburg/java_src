package aufgaben_schleifen;

import java.util.Scanner;
public class MatheLernenAddition {
/**
 * Erstellen Sie ein ausf�hrbares Programm mit dem Namen MatheLernprogramm.java. Das Programm erzeugt untenstehende 
 * Bildschirmausgabe. Bei den fett und kursiv dargestellten Zahlen handelt es sich um eine Benutzereingabe. 
 * Ihr Programm generiert zuf�llige Zahlen zwischen 1 und 100 und pr�ft, ob Sie das richtige Ergebnis eintippen. 
 * Das Programm wird mit der Eingabe 0 beendet und gibt dann untenstehende Statistik auf dem Bildschirm aus. 
 * 						11 + 5 = 16
 * 						richtig
 * 						65+92 = 157
 * 						richtig
 * 						79+73 = 153
 * 						falsch
 * 						48+44 = 0
 * 						Zeit: 16 Sekunden.
 * 						3 Aufgaben gel�st.  2 waren richtig. 	Eine Aufgabe war falsch.
 * Hinweis: Mit dem nachfolgenden Quelltextausschnitt kann die Zeit gemessen werden. Zwischen beginn und ende
 * sollte dann der Algorithmus stehen, der zeitlich gemessen werden soll: 
 * 						long beginn, ende; 
 * 						beginn = System.currentTimeMillis(); 
 * 						ende = System.currentTimeMillis(); 
 * 						System.out.println("Zeit: " + ((ende - beginn)/1000) + " Sekunden.");
 *  * Erweitern Sie das Programm mit mehreren Leveln. Z.B. nach 10 richtigen Eingaben werden Subtraktion, 
 *  Multiplikation, Division, Modulo etc abgefragt.
 * 
 * */
	public static void main(String[] args) {
	
		
		int zufallsZahl1 ;			int zufallsZahl2 ;			int summeRichtig ;			int summeEingabe = 0;
		long zeitStart 	 ;			int anzAufgaben = 0;		int anzRichtig  = 0 ;		int anzFalsch   = 0 ;
		long zeitEnde    ;	
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Starten des Mathe lernprogramms mit Additionen von Zahlen bis 100.\nBeenden der Aufgaben mit 0 ");
		
		// Zeiterfassung Start
		zeitStart = System.currentTimeMillis();
		
		do {
			// Zufallszahl generieren
			zufallsZahl1 = (int)(Math.random()* 100 + 1);
			zufallsZahl2 = (int)(Math.random()* 100 + 1) ;
			
			System.out.println();
			System.out.print(zufallsZahl1 +" + " + zufallsZahl2 + " = ");
			
			// Berechnung und Eingabe
			summeRichtig = zufallsZahl1 + zufallsZahl2 ;
			
			summeEingabe = in.nextInt();
			
			// Pr�fen Ergebnisse wenn nicht die 0 getippt wurde
			if (summeEingabe != 0) {
				if (summeRichtig == summeEingabe) {
					System.out.println("richtig");
					anzRichtig++;
				} else {
					System.out.println("falsch");
					anzFalsch++;
				  }
			}
			
		}while(summeEingabe != 0);
		// Berechnen der Gesamtanzahl der Aufgaben 
		anzAufgaben = anzRichtig + anzFalsch;
		
		// Zeiterfassung Ende
		zeitEnde = System.currentTimeMillis();
		
		// Ausgabe Ergebnis Zusammenfassung
		System.out.println("Training beendet ! \n"
				+ "Sie haben insgesamt " + anzAufgaben + " bearbeitet. \n"
				+ "davon waren: " + anzRichtig + " richtig \n"
				+ "und " + anzFalsch + " falsch. \n"
				+ "Sie haben daf�r : " + ((zeitEnde - zeitStart)/1000) + " Sekunden gebraucht.");
	}

}
