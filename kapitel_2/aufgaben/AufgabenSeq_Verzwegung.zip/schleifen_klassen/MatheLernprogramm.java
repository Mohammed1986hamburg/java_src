package aufgaben_schleifen;

import java.util.Scanner;

public class MatheLernprogramm {

	public static void main(String[] args) {
		int 	zufall1 =0;
		int 	zufall2 = 0;
		int 	ergebnisKorrekt = 0;
		int 	ergebnisUser = 0;
		int 	richtig = 0;
		int		falsch = 0;
		boolean nochmal = true;
		long 	beginn;
		long	ende;
		
		Scanner eingabe = new Scanner(System.in);
		
		beginn = System.currentTimeMillis();
	do{
			zufall1=(int)(Math.random()*100+1);
			zufall2=(int)(Math.random()*100+1);
			ergebnisKorrekt = zufall1 + zufall2;
			
			System.out.print(zufall1 + "+" + zufall2 + " = ");
			
			ergebnisUser = eingabe.nextInt();
						
			if(ergebnisUser == 0) {
				nochmal = false;
			}else {
				
				if(ergebnisUser == ergebnisKorrekt){
					
					richtig++;
					
					System.out.println("richtig");
				
				} else{
					falsch++;
					System.out.println("falsch");
				 }
			}
		}while(nochmal);
		
			ende = System.currentTimeMillis();
			
			System.out.println("Zeit: " + ((ende - beginn)/1000) + " Sekunden.");
			System.out.print((richtig+falsch)+" Aufgaben gel�st. ");
			
			switch(richtig)	{
				case 0: 
						System.out.print("Keine Aufgabe war richtig. ");
						break;
				case 1: 
						System.out.print("Eine Aufgabe war richtig. "); 
						break;
				default: 
						System.out.print(richtig + " waren richtig. ");
			}
			
			switch(falsch){
				case 0: 
						System.out.println("Keine Aufgabe war falsch.");
						break;
				case 1: 
						System.out.println("Eine Aufgabe war falsch.");
						break;
				default:
						System.out.println(falsch+" waren falsch.");
			}
	}

}
