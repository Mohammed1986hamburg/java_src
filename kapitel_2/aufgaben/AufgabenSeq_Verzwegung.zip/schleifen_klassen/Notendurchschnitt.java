package aufgaben_schleifen;
import java.util.Scanner;

public class Notendurchschnitt {

	public static void main(String[] args) {
		
		double 	note=1.0;
		double  notensumme=0.0;
		int     anzahl=0;
		Scanner eingabe = new Scanner(System.in);
		
		do {
			System.out.print("Note eingeben: ");
			note = eingabe.nextDouble();
			
			if((note <1.0 || note>6.0) && note!=0.0) {
				
				System.out.println("Falsche Note!!!");
			}
			else{
				notensumme = notensumme + note;
				anzahl++;
			}
		}while (note != 0.0);
		
		System.out.println("Notensumme = "+notensumme+", Notendurchschnitt = "+(notensumme/(anzahl-1)));

	}

}
