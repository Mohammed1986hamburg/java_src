package aufgaben_schleifen;

public class Permutation {

	public static void main(String[] args) {
		int a;
		int b;
		int c;
		int d;
		int zaehl = 0;
		System.out.println();
		
		for(a = 1;a <= 4;
				
				a++) {
		
			for(b = 1;b <= 4;
					
					b++) {
			
				for(c = 1; c <= 4;
						
						c++) {
				
					for(d = 1; d <= 4;
							
							d++){
						
						if( (a != b) && (a!=c) && (a!=d) && (b!=c) && (b!=d) && (c!=d) ){
							zaehl = zaehl + 1;
							System.out.println(a+" "+b+" "+c+" "+d);
						}
					}
				}
			}
		}
		System.out.println(zaehl + " M�glichkeiten");

	}

}
