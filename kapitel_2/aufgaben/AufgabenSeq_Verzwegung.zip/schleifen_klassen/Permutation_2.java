package aufgaben_schleifen;

import java.util.Scanner;
/* ************ Permutation ************** *
 *                                         *
 *              _  \\\\   _                *
 *               \_(°^°)_/                 *
 *                  ( )                    *
 *                 «/_\»                   *
 *                /▓▓▓▓▓\                  *
 *               /▓▓MJS▓▓\                 *
 *              |▓▓▓▓▓▓▓▓▓|                *
 *   ===================================   *
 * -== Permutation einer Zeichenkette. ==- *
 * Es darf kein Zeichen doppelt vorkommen. *
 *                                         *
 * ************ Permutation ************** */
public class Permutation_2 {

	public static void main(String[] args) {
		
		// Variablen
		char yesOrNo;
		Scanner abfrage = new Scanner(System.in);
		Scanner abfrage2 = new Scanner(System.in);

		System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
		System.out.println("▓▓▓▓ Permutation ▓▓▓▓");
		System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n");

		System.out.println("Achtung es dürfen KEINE gleichen Zeichen eingegeben werden!\n");
		
		// Schleife für Eingabe abzufragen
			schleife:
			for (;;) {												
			        System.out.println("\n\n\nMöchten Sie eine Zeichenkette eingeben? [j/n]");
					
			        // Das erste Zeichen der Eingabe einlesen
			        yesOrNo = abfrage.next().charAt(0);
			        
					// Wenn j oder J gedrückt wird starte die Abfrage
					if (yesOrNo == 'j' || yesOrNo == 'J') {					
						
						System.out.print("\nBitte geben sie eine Zeichenkette ein: ");
						String flush = abfrage2.nextLine();
						System.out.println();
						
						// Prüfen ob Zeichen doppelt vorkommen	
						for (int i = 0; i < flush.length();i++) {
							for (int j = (i+1); j < flush.length();j++) {
						
								// Wenn ein Zeichen gleich ist dann gebe eine Meldung aus und kehre zum
								// Sprungpunkt zurück
								if (flush.charAt(i) == (flush.charAt(j))){
									System.out.println("\nZeichen dürfen nur einmal vorkommen");
									continue schleife;
								}								
							}
						}
						// Wenn alles OK ist dann starte die Methode permutation
						permutation (flush);	
						
			        }

					// Wenn n oder N gedrückt wird beende das Programm
					if (yesOrNo == 'N' || yesOrNo == 'n') {				
			        	System.out.println("\nBis zum nächsten Mal!");
			        
			        	// Beende die Einlese-Funktion der Tastatur
			        	abfrage.close();
			        	abfrage2.close();								
			        	
			        	// Kehre zum System zurück
			        	System.exit(0);									
			        }
				}
	}
	
	public static void permutation(String komPlett) {
		
		// Variablen
		long stringLaenge = komPlett.length(), fakultaet = 1, zeitStart, zeitEnde;
		double zeitDauer;
		
		// Wenn kein Zeichen eingegeben wurde dann zurück in die main Methode
		if (komPlett == null || komPlett.length() == 0) {
			System.out.println("\nMind. ein Zeichen benötigt");
			return;
		}
		
		// Rechne die Möglichkeiten aus
		if (stringLaenge >= 0) {
			while (stringLaenge >1) {
				fakultaet *= stringLaenge;
				stringLaenge -= 1;
			}
		}
		
		// Beginne mit Zeiterfassung und starte die Permutation
		zeitStart = System.currentTimeMillis();
		permutation ("",komPlett);
		
		// Zeitstoppen und ausgeben
		zeitEnde = System.currentTimeMillis();
		zeitDauer = ((double)zeitEnde-zeitStart)/1000;
		
		System.out.printf("\n%d Möglichkeiten",fakultaet);
		System.out.println("\n\nDie Berechnung hat "+ zeitDauer + " Sekunden gedauert");
	}
	
	private static void permutation(String erstesZeichen, String restText) {
		
		// Wenn kein Zeichen mehr übrig ist dann gib den kompletten text aus
		if (restText.length()==0) {
			System.out.println(erstesZeichen);
			return;
		}
		// Ansonsten Wiederhole die Prozedur solange bis alle Zeichen überprüft wurden
		for (int i= 0; i <restText.length();i++) {
			permutation(erstesZeichen+restText.charAt(i), restText.substring(0,i)+ restText.substring(i+1, restText.length()));			
		}
	}
}
