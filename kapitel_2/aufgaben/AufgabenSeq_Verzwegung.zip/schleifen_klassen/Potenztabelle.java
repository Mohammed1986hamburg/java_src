package aufgaben_schleifen;

public class Potenztabelle {

	public static void main(String[] args) {
		int x;
		int xQuadrat = 0 ;
		int xHochDrei = 0;
		System.out.println("x \tx� \tx�");
		System.out.println("-------------------" );
		for(x = 1; x < 8; x++){
			xQuadrat = x*x;
			xHochDrei = xQuadrat*x;
			System.out.println(x+" \t "+xQuadrat +" \t"+xHochDrei);
		}

	}

}
