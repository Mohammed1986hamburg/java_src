package aufgaben_schleifen;

public class Quadratzahlen {

	public static void main(String[] args) {
		int summe = 0 ;
		int quadratZahl;
		
		for (int i = 1; i <= 40 ; i++){
			quadratZahl = i * i ;
			System.out.println(quadratZahl + ", ");
		
			summe = summe + quadratZahl;
		}
		
		System.out.println("Summe = "+summe);
	}

}
