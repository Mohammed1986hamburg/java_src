package aufgaben_schleifen;

import java.util.Scanner;

public class StellenZaehlen {

	public static void main(String[] args) {
		int zahl;
		int zaehler = 0;
		Scanner eingabe = new Scanner(System.in);
		
		System.out.println("kleinster Wert: " + Integer.MIN_VALUE + "  gr��ter Wert: " + Integer.MAX_VALUE);
		System.out.print("Von welcher Zahl sollen die Anzahl der Stellen gez�hlt werden: ");
				
		zahl = eingabe.nextInt();
		
		while (zahl != 0) {
			zahl=zahl/10;
			zaehler++;
		}
		
		System.out.println("Die Zahl hat " + zaehler + " Stelle(n).");
	}

}
