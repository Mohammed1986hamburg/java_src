package aufgaben_schleifen;

public class WuerfelDO {

	public static void main(String[] args) {
		int wuerfe = 1;
		int zahl = 0;
		do {
			zahl = (int)(Math.random() * 7 + 1);
			
			if (zahl < 7) {
			System.out.println("Wurf "+ wuerfe + ": " + zahl);
			}
			wuerfe++;
		}while(zahl < 7);
	}

}
