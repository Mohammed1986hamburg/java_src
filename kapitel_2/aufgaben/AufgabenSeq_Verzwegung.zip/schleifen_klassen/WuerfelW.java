package aufgaben_schleifen;

public class WuerfelW {

	public static void main(String[] args) {
		int wuerfe = 1;
		int zahl = 0;
		
		while(zahl < 7) {
			zahl = (int)(Math.random() * 7 + 1);
			if (zahl < 7) {
				System.out.println("Wurf "+wuerfe+": "+zahl);
				wuerfe++;
			}
		}
		System.out.println("Ende !");

	}

}
