package aufgaben_schleifen;

public class XXBlock {

	public static void main(String[] args) {
		
		for (int zeile = 1; zeile <= 10; zeile++) {
			for (int spalte = 1; spalte <= 10; spalte++) {
				System.out.print("x ");
				}
			System.out.println();
		}
	}

}
