package aufgaben_schleifen;

public class Zahlendreieck {

	public static void main(String[] args) {
		int zeilen = 8;
		
		for (int i = 1; i <= zeilen; i++) {
			System.out.print(i+": ");
			for (int j = i; j>=1; j--) {
				System.out.print(j+" ");
			}
			System.out.println();
		}

	}

}
