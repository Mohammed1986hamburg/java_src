package aufgaben_schleifen;

import java.util.Scanner;

public class Zahlenraten {

	public static void main(String[] args) {
		int 	obergrenze = 128;
		int 	untergrenze = 1;
		int 	zaehler = 0;
		int		eingabe;
		int		zufall;
		
		Scanner read = new Scanner(System.in);
		
		System.out.println("ZAHLENRATEN");
		System.out.print("Errate eine Zahl zwischen "+ untergrenze
				+" und "+obergrenze+"\n");
		
		zufall = (int)(Math.random()*(obergrenze-untergrenze+1)+untergrenze);
		
		do{
			zaehler++;
			System.out.print(zaehler + ". Versuch: ");
			eingabe = read.nextInt();
			
			if (eingabe < zufall) {
				System.out.println("Meine Zahl ist groesser!");
			}else {
				if (eingabe > zufall) {
					System.out.println("Meine Zahl ist kleiner!");
				}else {
					System.out.println("Du hast meine Zahl beim "
							+ zaehler + ". Versuch erraten.");
				}
			}
				
		} while (eingabe!=zufall);

	}

}
