package aufgaben_schleifen;

import java.util.Scanner;

public class Zahlumdrehen{

	public static void main(String[] args) {
		int wert;
		int zahl;
		int zaehler = 0;
		int multiplikator = 1;
		int umgedrehteZahl = 0;
		
		
		Scanner eingabe = new Scanner(System.in);
		
		System.out.println("kleinster Wert: " + Integer.MIN_VALUE + "  gr��ter Wert: " + Integer.MAX_VALUE);
		System.out.print("Welche Zahl soll umgedreht werden: ");
		zahl = eingabe.nextInt();
		
		wert = zahl;
		while (wert != 0) {
			wert = wert / 10;
			zaehler++;
		}
		wert = zahl;
		
		for (int i=1; i<zaehler; i++) {
			multiplikator = multiplikator * 10;
		}
		
		while(wert != 0) {
			umgedrehteZahl = ( wert % 10) * multiplikator + umgedrehteZahl;
			wert = wert / 10;
			multiplikator = multiplikator / 10;
		}
		System.out.println("Die umgedrehte Zahl lautet: " + umgedrehteZahl);
	}

}
