package aufgaben_schleifen;

public class _6UnterschiedlicheLottoZahlen_DW{

	public static void main(String[] args) {
		
		int a,b,c,d,e,f; 
 
			a = (int)(Math.random() * 49+1); 
			b = (int)(Math.random() * 49+1);
			c = (int)(Math.random() * 49+1); 
			d = (int)(Math.random() * 49+1); 
			e = (int)(Math.random() * 49+1); 
			f = (int)(Math.random() * 49+1); 
  
		
		System.out.println(a+" "+b+" "+c+" "+d+" "+e+" "+f); 

	}
}
