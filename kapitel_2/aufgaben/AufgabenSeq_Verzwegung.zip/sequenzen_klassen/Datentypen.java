package oca.basic.uebungen;

public class Datentypen {
	 public static void main(String[] args)  { 
		
		 boolean lichtSchalterAn = true; 
		 System.out.println("Wert f�r boolean: "+lichtSchalterAn); 
		 
		 lichtSchalterAn = false; 
		 System.out.println("Wert f�r boolean: "+lichtSchalterAn);
		
		 char zeichen='H';
		 System.out.println("char: " + zeichen); 
		
		 byte m = 127;  
		 System.out.println("h�chster Wert f�r byte: "+m);
		
		 m = -128; 
		 System.out.println("kleinster Wert f�r byte: "+m); 
		 short n = 32767;
		 System.out.println("h�chster Wert f�r short: "+n); 
		 n = -32768;  
		 System.out.println("kleinster Wert f�r short: "+n); 
		 int a = 2147483647;  
		 System.out.println("h�chster Wert f�r int: "+a); 
		 a = -2147483648;  
		 System.out.println("kleinster Wert f�r int: "+n);   
		 //Achte auf Pr�fix bzw. Literal l bzw. L  
		 long d = 9223372036854775807l; 
		 System.out.println("h�chster Wert f�r long: "+d); 
		 long e = -9223372036854775808L;  
		 System.out.println("h�chster Wert f�r long: "+e); 
		 //Achte auf Pr�fix bzw. Literal f bzw. F  
		 float j = 7.1234567890123F; 
		 System.out.println("float = " + j);   
		 //Achte auf Pr�fix bzw. Literal d bzw. D 
		 double k = 7.1234567890123459999d;  
		 System.out.println("double= " + k); 
	}
}


