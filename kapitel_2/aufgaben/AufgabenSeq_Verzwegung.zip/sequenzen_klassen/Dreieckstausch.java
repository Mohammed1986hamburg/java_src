package oca.basic.uebungen ;
public class Dreieckstausch
{
	public static void main(String[] args)
	{
		
		int  a = 7;
		int  b = 13;
		int varTemp;
		System.out.print("a = "+ a +" b =  "+ b + "\t");
		varTemp = a;
		a = b;
		b = varTemp;
		System.out.println("a = "+ a + " b = "+b);
	}

}