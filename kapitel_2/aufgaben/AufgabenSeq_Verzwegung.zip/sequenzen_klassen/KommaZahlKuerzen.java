package oca.basic.uebungen ;


public class KommaZahlKuerzen
{
	public static double kommazahlKuerzen(double a)
	{
				
//		double  a = 2.3897654;
		a = a *100;
		a = (int)(a);
		a = a /100;
		return a;
	}

}