package oca.basic.uebungen;

public class KommazahlKuerzen_1 {

	public static void main(String[] args) {
		double zahl = 2.3897654;
		double zahl1;
		int hilfsVariable;
		double ergebnisMathFunktion;
		double ergebnis;
		
		zahl1 = zahl *100;
		System.out.println(zahl1);
		zahl1= (int) (zahl1);
		System.out.println(zahl1);
		zahl1 =zahl1 / 100;
		System.out.println(zahl1);
		
		zahl = Math.round(zahl);
		System.out.println(zahl);
		zahl = 2.3897654;
		zahl = Math.round(zahl*100)/100.0;
		System.out.println(zahl);
		

	}

}
