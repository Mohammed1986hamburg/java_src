package oca.basic.uebungen;
public class Konstante
{
	// Konstante Variable die f�r die gesamte Klasse g�ltig ist 
	final  static double  PI = 3.1415926535897932384626433832795;

	public static void main(String[] args)
	{
		int radius = 5;
		double flaeche;
		double test ;
		System.out.println(PI);
		flaeche = PI * radius * radius;
		System.out.println(flaeche);
		// Berechnung in einer Zeile
		test = (double)((int) (PI * 100))/100;
		System.out.println("tst" + test);
	}

}