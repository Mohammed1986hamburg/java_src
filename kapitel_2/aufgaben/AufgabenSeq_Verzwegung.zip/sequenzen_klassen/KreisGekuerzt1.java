package oca.basic.uebungen;


public class KreisGekuerzt1
{



	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		int radius = 5 ;
		double hoehe = 10.0 ;
		double  PI = 3.141592653589793 ;
		double flaeche =  radius * radius * PI ;
		double umfang = radius * 2 * PI ;
		double volumen = radius * radius * PI * hoehe ;
		
		PI = PI * 100;
		PI = (int) (PI);
		PI = PI / 100;
		
		flaeche = flaeche * 100;
		flaeche = (int) (flaeche);
		flaeche = flaeche / 100;
		
		umfang = umfang * 100;
		umfang = (int) (umfang);
		umfang = umfang / 100;
		
		volumen = volumen * 100;
		volumen = (int) (volumen);
		volumen = volumen / 100;
	 
	
		System.out.println("PI = " + PI) ;
		System.out.println( "Der Durchmesser betr�gt : "  + (double) ( radius * 2)) ;
		System.out.println( "Die Fl�che betr�gt : "  + flaeche) ;
		System.out.println( "Der Umfang betr�gt : "  + umfang) ;
		System.out.println( "Das Volumen betr�gt : "  + volumen) ;
	}

}