package oca.basic.uebungen;

import java.util.Scanner;

public class Kreisgekuerzt_0 {
	public static void main(String[] args)  { 
		double radius;
		double hoehe;
		double durchmesser;
		double flaeche;
		double umfang;
		double volumen; 
		// Scanner ist eine Klasse zum einlesen der Konsolen Eingabe durch den Benutzer
		Scanner eingabe = new Scanner(System.in);  
		
		System.out.println("Bitte geben Sie den Radius ein:"); 
		radius = eingabe.nextDouble(); 
		System.out.println("Bitte geben Sie die H�he ein:"); 
		hoehe = eingabe.nextDouble();
		
		// Berechnungen mit Voreingestellter PI Funktion durch die Math Bibliothek von Java
		flaeche = radius * radius * Math.PI; 
		durchmesser = radius * 2 ; 
		umfang = radius * 2 * Math.PI ; 
		volumen=radius*radius* Math.PI * hoehe ; 
		
		// Berechnungen die auf 2 Nachkommastellen die Ergebnisse k�rzen
		flaeche =  (double) ( (int)(flaeche * 100) )  / 100; 
		umfang =   (double) ( (int)(umfang  * 100) )  / 100; 
		volumen =  (double) ( (int)(volumen * 100) )  / 100;
		
		// Ausgabeanweisungen der Ergebnisse
		System.out.println("PI = " + (double)( (int)(Math.PI*100) ) / 100); 
		System.out.println("Der Durchmesser betr�gt " + durchmesser); 
		System.out.println("Die Fl�che betr�gt " + flaeche); 
		System.out.println("Der Umfang betr�gt " + umfang); 
		System.out.println("Das Volumen betr�gt " + volumen); 
	}

	
}
