package oca.basic.uebungen;
/** ******************************************************************************************
 * Erstellen Sie ein ausf�hrbares Programm mit dem Namen Modulo.java. Das Programm f�hrt mit 
 * dem Operator / (geteilt) und dem Modulo Operator % zwei Berechnungen aus und erzeugt 
 * nachfolgende Bildschirmausgabe: 
 * 									7 : 2 = 3 Rest 1
 * ******************************************************************************************
 * */

public class Modulo {
	public static void main(String[] args)  { 
		// Variablen Initialisierung
		int divident  = 7 ;
		int divisor = 2 ;
		int quotient =   divident / divisor;
		int rest 	 =  divident % divisor  ;
		
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("          mit Variablen berechnet "          );
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println();
		System.out.println( divident+ " / " + divisor +" = " + quotient + " Rest "+ rest);
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("      direkt in Ausgabe berechnet "          );
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println();
		System.out.println("7 : 2 = "+7/2+" Rest "+ 7%2); 
	}

}
