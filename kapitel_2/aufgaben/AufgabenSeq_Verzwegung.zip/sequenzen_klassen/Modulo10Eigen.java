package oca.basic.uebungen;

/** ***************************************************************************************************
 * Erstellen Sie ein ausf�hrbares Programm mit dem Namen Modulo10Eigen.java. Das Programm erzeugt
 * untenstehende Bildschirmausgabe.
 *  								1023453 % 10 = 3
 *  Allerdings d�rfen Sie in Ihrem Programm nicht mit dem Modulo-Operator rechnen: 1023453 % 10 = 3
 * ****************************************************************************************************
 * */

public class Modulo10Eigen {
	public static void main(String[] args)  { 
		// Initialisieren einer Zahl
		int zahl = 1023453; 
		int zahl11 = 13;
		int rest;
		int division;
		int zwischen;
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("             mit Zahl 1023453                     ");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println();
		// Ausgabe  Zahl
		System.out.println(zahl);
		// Division durch 10 --> wie oft geht die 10 in die zahl 1023453
		division = zahl / 10 ;
		// Ergebnis der Division durch 10
		System.out.println("Die 10 geht genau " + division + " mal in die 1023453");
		// Zwischenrechnung --> das ergebnis der Rechnung wie oft ist 10 mal die division
		zwischen = (division *10) ;
		// Ergebnis der Zwischenrechnung 
		System.out.println("10 mal die "+ division + " ergibt :"+ zwischen);
		// Jetzt nur noch das Ergebnis der Zwischenrechnung von der Zahl abziehen und �brig bleibt der Rest
		rest = zahl - zwischen;
		// Ausgabe des Rest
		System.out.println("Die " + zahl + " minus " + zwischen + " ergibt einen Rest " + rest);
		
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("     Berechnung direkt in der Ausgabe             ");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println();
		// Ausgabe ohne Zwischenrechnung
		System.out.println(zahl+" % 10 = "+(zahl-(zahl/10)*10)); 
	    
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("                  mit Zahl 13                     ");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println();
		// Ausgabe  Zahl
		System.out.println(zahl11);
		// Division durch 10 --> wie oft geht die 10 in die zahl 1023453
		division = zahl11 / 10 ;
		// Ergebnis der Division durch 10
		System.out.println("Die 10 geht genau " + division + " mal in die 13");
		// Zwischenrechnung --> das ergebnis der Rechnung wie oft ist 10 mal die division
		zwischen = (division *10) ;
		// Ergebnis der Zwischenrechnung 
		System.out.println("10 mal die "+ division + " ergibt :"+ zwischen);
		// Jetzt nur noch das Ergebnis der Zwischenrechnung von der Zahl abziehen und �brig bleibt der Rest
		rest = zahl11 - zwischen;
		// Ausgabe des Rest
		System.out.println("Die " + zahl11 + " minus " + zwischen + " ergibt einen Rest " + rest);
			
	
	}

}
