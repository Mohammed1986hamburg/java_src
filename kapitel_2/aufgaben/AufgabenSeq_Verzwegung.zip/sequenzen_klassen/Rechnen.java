package oca.basic.uebungen;
/** ******************************************************************************************************************
 *  Erstellen Sie ein ausf�hrbares Programm mit dem Namen Rechnen.java. Das Programm f�hrt Addition (+),
 *  Subtraktion (-), Multiplikation (*) und Division (/) mit den Zahlen 6 und 7 ohne den Einsatz von 
 *  Variablen aus. Die Bildschirmausgabe soll nachfolgendes Aussehen haben. 
 *  6 + 7 = 13
 *  6 * 7 = 42
 *  6 � 7 = -1
 *  6 / 7 = 0
 *  6.0 / 7.0 = 0.8571428571428571
 *  6.0 / 7 = 0.8571428571428571
 *  6 / 7.0 = 0.8571428571428571
 * **********************************************************************************************************************
 * */

public class Rechnen {
	
	public static void main(String[] args)  { 
		// Initialieren der Variablen f�r die Berechnung
		// Verwendung der Ungarischen Notation --> der erste Buchstabe steht f�r den verwendeten datentyp
		// i = int und d = double , erm�glicht dieselbe Bezeichnung mehrfach zu Verwenden und den Datentyp immer zu wissen
		int iZahl6 		= 6		;	
		int iZahl7 		= 7		;
		double dZahl6 	= 6.0	;
		double dZahl7 	= 7.0 	;
		// Deklarieren der Variablen zur Speicherung der Rechenergebnisse 
		int iAdd,iSub,iMul,iDiv	;
		double dDiv				;
		
		// Erste Berechnungen 
		iAdd = iZahl6 + iZahl7 ;
		iSub = iZahl6 - iZahl7 ;
		iMul = iZahl6 * iZahl7 ;
		iDiv = iZahl6 / iZahl7 ;
		dDiv = dZahl6 / dZahl7 ;
		
		// Ausgabe der ersten Rechenergebnisse
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Berechnungen mit Variablen als Ergebnisspeicher ");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("6 + 7 = " + iAdd); 
		System.out.println("6 * 7 = " + iMul); 
		System.out.println("6 - 7 = " + iSub);
		System.out.println("6 / 7 = " + iDiv);
		System.out.println("6.0 / 7.0 = " + dDiv);
		
		// �berschreiben der Rechenergebnisse der Variablen iDiv und dDiv 
		iDiv = (int) (dZahl6 / iZahl7) ; 	// (int) ist ein Typecast, dh. der Ergebniswert wird in einen Ganzzahligen Wert gezwungen
											// da die Variable iDiv vom Datentyp Integer ist und double Werte nicht darstellen kann.
		dDiv = dZahl6 / iZahl7		;
		
		// Ausgabe der beiden obigen Rechenanweisungen
		System.out.println(dZahl6 +" / "+ iZahl7 +" = in einer Int variable --> " + iDiv);
		System.out.println(dZahl6 +" / "+ iZahl7 +" = in einer double variable --> " + dDiv);
		
		// Erneutes �berschreibender Variablen iDiv und dDiv zur Umsetzung der letzten beiden Rechenanweisungen
		iDiv = (int) (iZahl6 / dZahl7) ; 	// (int) ist ein Typecast, dh. der Ergebniswert wird in einen Ganzzahligen Wert gezwungen
											// da die Variable iDiv vom Datentyp Integer ist und double Werte nicht darstellen kann.
		dDiv = iZahl6 / dZahl7		;
		
		// Ausgabe der letzten beiden Rechenanweisungen mit Variablen
		System.out.println(iZahl6 +" / "+ dZahl7 +" = in einer Int variable --> " + iDiv);
		System.out.println(iZahl6 +" / "+ dZahl7 +" = in einer double variable -->" + dDiv);
		
		// Ab hier werden keine Variablen zur Berechnung genutzt sondern direkt in die 
		// Ausgabe Anweisung geschrieben
		System.out.println();
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("       Berechnungen direkt in der Ausgabe "      );
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.print(" 6 + 7 = "); 
		System.out.println(6+7);
		System.out.println(" 6 * 7 = " + (6*7)); 
		System.out.println(" 6 - 7 = " + (6-7));
		System.out.println(" 6 / 7 = " + (6/7));
		System.out.println(" 6.0 / 7.0 = " + (6.0/7.0));
		System.out.println(" 6.0 / 7 = " + (6.0/7));
		System.out.println(" 6 / 7.0 = " + (6/7.0)); 
		
	}

}
