package oca.basic.uebungen;
import java.util.Scanner; 
public class Volumen {
	 public static void main(String[] args)  { 
		
		 double laenge = 10.9;
		 double breite = 3.1;
		 double hoehe = 3.5; 
		 double volumen;
		 
		 volumen = laenge * breite * hoehe;
		 
		 System.out.println("Das Volumen betr�gt : " + volumen);
		 System.out.println();
		 System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		 System.out.println("             Ab hier mit Eingabeaufforderung              ");
		 System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
//~~~~~~~~~~~~~~~~~~~~~~~  mit Eingabe der Wert  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		 Scanner eingabe = new Scanner(System.in); 
		// Variablen werden die obigen wiederbenutzt
		 
		// Ausgabe f�r den Benutzer , damit er wei�, was zu tun ist
		 System.out.print("L�nge: "); 
		// die Eingabe des Benutzers wird der als Zeichenkette eingelesen und durch die Methode nextDouble()
		// versucht in einen Gleitkommawert zu wandeln. 
		// Anschlie�end wird der erfolgreich umgewandelte Wert der Variablen links zugewiesen
		 laenge = eingabe.nextDouble(); 
		 
		// Ausgabe f�r den Benutzer , damit er wei�, was zu tun ist
		 System.out.print("Breite: "); 
		
		// die Eingabe des Benutzers wird der als Zeichenkette eingelesen und durch die Methode nextDouble()
		// versucht in einen Gleitkommawert zu wandeln. 
		// Anschlie�end wird der erfolgreich umgewandelte Wert der Variablen links zugewiesen
		 breite = eingabe.nextDouble();
		// Ausgabe f�r den Benutzer , damit er wei�, was zu tun ist
		 System.out.print("H�he: "); 
		// die Eingabe des Benutzers wird der als Zeichenkette eingelesen und durch die Methode nextDouble()
		// versucht in einen Gleitkommawert zu wandeln. 
		// Anschlie�end wird der erfolgreich umgewandelte Wert der Variablen links zugewiesen
		 hoehe = eingabe.nextDouble();
		
		 // Berechnungsanweisung f�r das Volumen
		 volumen=laenge*breite*hoehe; 
		 
		 // Ausgabe Anweisung
		 System.out.println("Das Volumen betr�gt: "+volumen); 
	}

}
