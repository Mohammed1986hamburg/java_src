package oca.basic.uebungen; 

public class Volumen2
{

	public static void main(String[] args)
	{
		
		double  laenge = 10.9;
		double  breite = 3.1;
		double  hoehe = 3.5;
		double  volumen = laenge * breite * hoehe;
		System.out.println("Das Volumen betr�gt : " + volumen) ;
	}

}