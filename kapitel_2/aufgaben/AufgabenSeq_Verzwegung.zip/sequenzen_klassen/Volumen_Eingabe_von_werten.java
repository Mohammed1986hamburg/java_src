package oca.basic.uebungen;
import java.util.Scanner;


public class Volumen_Eingabe_von_werten
{

	public static void main(String[] args)	{
		
		String laenge;
		String breite;
		String hoehe;
		double length, width,height;
		double volumen;
		
		// Erzeugung eines Objektes der Klasse Scanner
		//	TYP			Bezeichner d. Objektes	Zuweisung			NEU			Konstruktoraufruf
		Scanner 		input 				      = 				new  		Scanner(System.in);	
		
		// Beginn des Einlesen der Werte und Umwandeln in Numerische Werte
		// Benutzerfreundlichkeit !!! Ausgabe auf Konsole was Benutzer tun soll !!!
		System.out.println("Geben Sie die L�nge ein");
		laenge = input.nextLine();
		length = Double.parseDouble(laenge);
		
		System.out.println("Geben Sie die Breite ein");	
		breite = input.nextLine();
		width = Double.parseDouble(breite);
		
		System.out.println("Geben Sie die H�he ein");
		hoehe = input.nextLine();
		height = Double.parseDouble(hoehe);
			
		// Berechnung mit den eingegebenen Werten
		volumen = (length * width * height);
		
		// Ausgabe Anweisungen
		System.out.println(laenge);
		System.out.println(breite);
		System.out.println(hoehe);
		System.out.println("Volumen ist: " + volumen);
	}

}