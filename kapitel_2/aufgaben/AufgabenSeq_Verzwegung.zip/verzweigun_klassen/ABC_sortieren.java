package oca.kontrollstrukturen.uebungen;

public class ABC_sortieren {

	public static void main(String[] args) {
		int hilf; 
		int a=3;
		int b=1;
		int c=2;
		
		System.out.println("vorher:  a="+a+" b="+b+" c="+c); 
		
		if(a>b) { 
			hilf=b; b=a; a=hilf; 
		} 
		if(a>c) {
			hilf=c; c=a; a=hilf;
		}
		if(b>c) {
			hilf=c; c=b; b=hilf;
		} 
		
		System.out.println("nachher: a="+a+" b="+b+" c="+c);

		

	}

}
