package oca.kontrollstrukturen.uebungen;

public class Bedingungsoperator {

	public static void main(String[] args) {
		
		 int x = 15 ;
		 int y = 12;
		 boolean zugang = false;
		 int minimum ;
	
		// *****************************  Mit If Else Anweisung   *****************************************
		 if (x < y) {
			 minimum = x;
			 System.out.println(minimum);
		 }
		 else {
			 minimum = y;
			 System.out.println(minimum);
		 }
		 // Ausgabe Zugang Bedingung pr�fen
		 if (zugang) {
			 System.out.println(zugang);
			 System.out.println(" -- >    offen");
		 }
		 else {
			 System.out.print(zugang);
			 System.out.println(" -- >    geschlossen");
		 }
		//*************************************************************************************************
		// ************************************************************************************************ 
		//********************************  Mit Bedingungsoperator ?   ************************************
		 // Bedingungsoperator ?  ist eine Kurzform einer if else Anweisung
		 
	//	SpeicherVariable	Zuweisung		Bedingung	Bedingungsoperator	Anweisung1	: 	Anweisung 2
	//	 																	wenn wahr		wenn falsch
		 	minimum 			= 				(x < y) 			? 			x 		: 		y;
		 
		 System.out.println(minimum); 
		 
		 // Funktioniert auch mit Strings  die Zeichenkette wird der Stringvariablen zugewiesen falls
		 // die boolesche Variable wahr wird "offen" und wenn sie falsch wird "geschlossen"
		
		 String zustand = zugang ? "offen" : "geschlossen" ;
 	
		 System.out.println(zustand);

		 // *************************************************************************************************

	}

}
