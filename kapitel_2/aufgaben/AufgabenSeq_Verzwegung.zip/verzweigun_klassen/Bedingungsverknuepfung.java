package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class Bedingungsverknuepfung {

	public static void main(String[] args) {
		int wert=200; 
		int werteingabe ;
		Scanner in = new Scanner (System.in);
		System.out.println("Geben Sie eine ganze Zahl ein");
		werteingabe = in.nextInt();
		
		if(werteingabe >=100 && werteingabe <=200)     //logischer UND-Operator 
			System.out.println("1.) && " + werteingabe); 
		
		
		if(werteingabe >=150 || werteingabe<=10) {    //logischer ODER-Operator  
			
			System.out.print("2.) || "); 
			System.out.println(werteingabe); 
			} 
		
		else System.out.println("Ende");		// Wird IMMER ausgegeben
		}


	}

