package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class GeradeUngerade {

	public static void main(String[] args) {
		int zahl;
		Scanner eingabe = new Scanner(System.in); 
		
		System.out.print("Bitte geben Sie eine Zahl ein: ");
		zahl = eingabe.nextInt();
		
		if(zahl%2==0) {
			System.out.println("Die Zahl ist gerade."); 
		}
		else { System.out.println("Die Zahl ist ungerade.");
		}
	}
}
