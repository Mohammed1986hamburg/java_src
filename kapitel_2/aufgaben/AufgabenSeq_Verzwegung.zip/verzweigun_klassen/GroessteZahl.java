package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class GroessteZahl {

	public static void main(String[] args) {
		
		Scanner eingabe = new Scanner(System.in); 
		int zahl1;
		int zahl2;
		int zahl3;
		System.out.println("1. Zahl: ");
		zahl1 = eingabe.nextInt(); 
		
		System.out.println("2. Zahl: ");
		zahl2 = eingabe.nextInt();
		
		System.out.println("3. Zahl: ");
		zahl3 = eingabe.nextInt();
		
		if(zahl1>zahl2 && zahl1>zahl3) {
			System.out.println("Zahl 1 = "+zahl1+" ist die gr��te Zahl.");
		}
		else {
			if(zahl2>zahl3) {
				System.out.println("Zahl 2 = "+zahl2+" ist die gr��te Zahl.");
			}
			else {
				System.out.println("Zahl 3 = "+zahl3+" ist die gr��te Zahl."); 
			}
		}

	}

}
