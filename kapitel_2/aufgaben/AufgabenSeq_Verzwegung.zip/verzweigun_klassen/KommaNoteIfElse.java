package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class KommaNoteIfElse {

	public static void main(String[] args) {
		double note;
		Scanner eingabe = new Scanner(System.in); 
		
		System.out.print("Bitte geben Sie eine Kommanote ein (z.B. 3,76): ");
		note = eingabe.nextDouble(); 
		
		if(note>=1 && note <1.5) {
			System.out.println("sehr gut"); 
		}
		else { 
			if(note >=1.5 && note<2.5) {
				System.out.println("gut"); }
			else {
				if(note >=2.5 && note<3.5) {
					System.out.println("befriedigend");
				}
				else {
					if(note >=3.5 && note<4.5) {
						System.out.println("ausreichend");
					}
					else {
						if(note >=4.5 && note<5.5) {
							System.out.println("mangelhaft");
						}
						else {
							if(note >=5.5 && note<=6.0) {
								System.out.println("ungen�gend");
							}
							else {
								if(note <1.0 || note > 6.0) {
									//optional
									System.out.println("keine g�ltige Note");
								}
							}
						}
					}
				}
			}
		}
	}
}
