package oca.kontrollstrukturen.uebungen;

import java.util.Arrays;
import java.util.Random;

public class LottoZahlen {

	
	
	public static void main(String[] args) {
		
		int[] array = x_aus_y(6, 49);				  			// Eine Funktion die 6 zuf�llige Ganzzahlen aus einem Pool von 49 Ganzzahlen zur�ckgibt
        String s = Arrays.toString(array);						// Die ausgew�rfelten Zahlen aus dem Array in die String-Variable s speichern
        System.out.println("Die Lottozahlen sind: " +s);		// Ausgabe
        
        int[] array1 = x_aus_y(5, 30);
         s = Arrays.toString(array1);
         System.out.println("Die Lottozahlen sind: " +s);
        int[] array2 = x_aus_y(6, 49);
        s = Arrays.toString(array2);
        System.out.println("Die Lottozahlen sind: " +s);
        int[] array3 = x_aus_y(5, 30);
        s = Arrays.toString(array3);
        System.out.println("Die Lottozahlen sind: " +s);
        int[] array4 = x_aus_y(8, 55);
        s = Arrays.toString(array4);
        System.out.println("Die Lottozahlen sind: " +s);
        int[] array5 = x_aus_y(6, 49);
        s = Arrays.toString(array5);
        System.out.println("Die Lottozahlen sind: " +s);
        
    }

	
	
	
	
	
    private static int[] x_aus_y(int x, int y) {
        int[] array = new int[x];								// Erstellt ein Array mit x k�stchen/feldern (in diesem Fall also 6) Siehe Zeile 10
        Random random = new Random();							// Ruft die Zufallsfunktion auf und weisst sie der random-Instanz zu
        aLabel:													// Sprungadresse
        for (int i = 0; i < x;) {								// Schleife (Solange die Schleife durchlaufen lassen bis das Array gef�llt ist
            array[i] = random.nextInt(y) + 1;					// Die aktuelle Position im Array mit einem zuf�lligen Wert aus dem y-Pool f�llen 
         
            for (int j = 0; j < i; j++) {						// Wenn x mit dem Wert aus y gef�llt ist dann z�hle j hoch bis zur aktuellen Position von i
               
            	if (array[i] == array[j]) {						// Wenn i = j ist dann
                    continue aLabel;							// Springe zu aLabel
                }
            }
            i++;												// i um 1 erh�hen
        }
        return array;											// gib die Werte zur�ck an die Stelle von wo die Funktion aufgerufen wurde...
		
	}
}
    
		