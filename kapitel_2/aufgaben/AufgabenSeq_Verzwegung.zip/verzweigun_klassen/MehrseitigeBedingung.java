package oca.kontrollstrukturen.uebungen;

public class MehrseitigeBedingung {

	public static void main(String[] args) {
		int alter = 18; 
		
		if(alter < 7) {
			System.out.println("Gesch�ftsunf�higkeit");
		}else {
			if(alter < 18) {
				System.out.println("beschr�nkte Gesch�ftsf�higkeit.");
			}
			else {
				System.out.println("unbeschr�nkte Gesch�ftsf�higkeit.");
			}
		}
	}
}
