package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

/*	*** Aufgabe 10 ***
 *  Das Programm fragt das Alter ab.
 *  ---------------------------------------------------------	*
 * 	Unter 7 Jahren ist die Person Gesch�ftsunf�hig				*
 * 	Ab    7 Jahren ist die Person beschr�nkt Gesch�ftst�chtig   *
 * 	Ab   18 Jahren ist die Person voll Gesch�ftst�chtig.		*
 * 	---------------------------------------------------------	*
 */
public class MehrseitigeBedingung_1 {

	public static void main(String[] args) {
		
		// Initialisieren
		
		Scanner input = new Scanner(System.in);
		String eingabeAlter;
		
		int alter;
		int vollTuechtig = 18;
		int teilTuechtig = 7;
		
		// Abfrage des Alters
		
		System.out.println("��Aufgabe 10 �\n");
		System.out.println("Vor dem Kauf muss noch Ihr Alter gepr�ft werden!\n");
		System.out.print("Bitte geben sie Ihr Alter ein: ");
		
		eingabeAlter = input.next();
		alter = Integer.parseInt(eingabeAlter);
		
		// Verzweigung
		if (alter >= vollTuechtig) {
			
			System.out.println("\n\nDu kannst alles KAUFEN *H�nde reib*");
			System.out.println("\n\t- Vollt�chtig -");
		
		} else {
			
			if (alter >=teilTuechtig) {
				
				System.out.println("\n\nDu kannst wenigstens ein bisschen kaufen!");
				System.out.println("\n\t- Teilt�chtig -");

			} else {
				
				System.out.println("\n\nMach das du abhaust!!!");
				System.out.println("\n- Unt�chtig -");
			  
			  }
		  }
		input.close();
	}

}
