package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

/**
 */
public class MehrseitigeBedingung_2
{



	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		int alter ;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Geben Sie Ihr Alter ein:");
		alter = input.nextInt();

		input.close();
		
		
		if (alter >= 7)
		{
			if (alter >= 18)
			{
				System.out.println("Unbeschr�nkte Gesch�ftsf�higkeit") ; 
			}
			else
			{
				System.out.println("Beschr�nkte Gesch�ftsf�higkeit !!!") ;
			}
		}
		else
		{
			System.out.println("Gesch�ftsunf�higkeit !!!") ;
		}
	}

}