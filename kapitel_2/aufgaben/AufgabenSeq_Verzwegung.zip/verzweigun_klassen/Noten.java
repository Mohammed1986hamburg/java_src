package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class Noten {

	public static void main(String[] args) {
		int note = 0 ; 
		
		Scanner eingabe = new Scanner(System.in); 
		
		System.out.print("Bitte geben Sie eine Note ein: "); 
		note = eingabe.nextInt(); 
		
		if(note==1) 
			System.out.println("sehr gut"); 
		
		else 
			if(note==2) 
				System.out.println("gut");
			
			else 
				if(note==3) 
					System.out.println("befriedigend");
					
				else  
					if(note==4) 
						System.out.println("ausreichend");
						 
					else 
						if(note==5) 
							System.out.println("mangelhaft"); 
												
						else 
							if(note==6) 
								System.out.println("ungen�gend");
							
							else  
								System.out.println("keine g�ltige Note");
	}
}
