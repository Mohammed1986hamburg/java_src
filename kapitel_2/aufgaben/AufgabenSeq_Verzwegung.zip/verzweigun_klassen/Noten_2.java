package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class Noten_2 {

	public static void main(String[] args) {
		int note = 0 ; 
		
		Scanner eingabe = new Scanner(System.in); 
		
		System.out.print("Bitte geben Sie eine Note ein: "); 
		note = eingabe.nextInt(); 
		
		if(note==1) {
			System.out.println("sehr gut"); 
		}
		if(note==2) {
			System.out.println("gut");
		}
		if(note==3) {
			System.out.println("befriedigend");
		}
		if(note==4) {
			System.out.println("ausreichend");
		} 
		if(note==5) {
			System.out.println("mangelhaft"); 
		}						
		if(note==6) {
			System.out.println("ungen�gend");
		}
		if (note > 6 || note < 1) {
		System.out.println("keine g�ltige Note");
		}

	}

}
