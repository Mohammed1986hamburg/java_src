package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

/*	*** Aufgabe 11 ***
 *  
 *  Das Programm fragt die Note ab.
 *  ---------------------------------------------------------	*
 * 	Eingabem�glichkeit: 1-6									 	*
 * 															 	*
 * 	Bei einer anderen Eingabe als 1 - 6 wird eine			 	*
 *  Fehlermeldung ausgegeben.								 	*
 * 	---------------------------------------------------------	*
 */
public class Noten_3 {

	public static void main(String[] args) {
		
		// Initialisieren
		
		Scanner input = new Scanner(System.in);
		String eingabeNote;
		
		int note;
		
		// Abfrage der Note
		
		System.out.println("��Aufgabe 11 �\n");
		System.out.println("Unser Schulsystem hatte einen technischen Defekt\n");
		System.out.println("Das Klausur-Ergebnis in Prozeduraler Programmierung fehlt noch\n");
		System.out.print("Bitte geben sie Ihre Note ein (1-6): ");
		
		eingabeNote = input.next();
		note = Integer.parseInt(eingabeNote);
		
		// Switch - Case
		
		switch(note) {
		
			case (1):
						System.out.println("\nSehr gut!");
						System.out.println("Wenigstens einer hat zugeh�rt!!!");
						break;
			case (2):
						System.out.println("\nGut!");
						System.out.println("Klausur gut bestanden");
						break;
			case (3):
						System.out.println("\nBefriedigend");
						System.out.println("Klausur bestanden");
						break;
			case (4):
						System.out.println("\nAusreichend");
						System.out.println("H�ttest mal besser zugeh�rt");
						break;
			case (5):
						System.out.println("\nMangelhaft");
						System.out.println("Du hast Teilgenommen");
						break;
			case (6):
						System.out.println("\nUnbefriedigend");
						System.out.println("Wo warst du die letzten Wochen?");
						break;
			default:
						System.out.println("\nKeine g�ltige Note");
						System.out.println("Was verstehst du bei 1-6 nicht???");
		}
		
		input.close();
	}

}
