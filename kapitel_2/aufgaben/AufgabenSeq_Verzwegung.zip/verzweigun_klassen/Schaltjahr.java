package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class Schaltjahr {

	public static void main(String[] args) {
		int jahr; 
		Scanner eingabe = new Scanner(System.in); 
		
		System.out.print("Bitte geben Sie eine Jahreszahl ein:"); 
		jahr = eingabe.nextInt();
		
		if(jahr %400==0 || (jahr %4 ==0 && jahr % 100 !=0) ) {
			System.out.println("Bei dem Jahr "+jahr +" handelt es sich um ein Schaltjahr.");
		} else {
			System.out.println("Bei dem Jahr "+jahr +" handelt es sich um KEIN Schaltjahr.");
		}
	}
}