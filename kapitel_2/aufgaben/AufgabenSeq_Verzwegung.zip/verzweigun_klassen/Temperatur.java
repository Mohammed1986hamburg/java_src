package oca.kontrollstrukturen.uebungen;

import java.util.Scanner;

public class Temperatur {

	public static void main(String[] args) {
		int temperatur = 0;
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Bitte geben Sie eine Temperatur ein:");
		temperatur = eingabe.nextInt();
		
		if (temperatur < 0) {
			System.out.println("Ziehen Sie sich sehr warm an, " + "es hat lediglich " + temperatur + " Grad, also Minusgrade.");
		}
		else {
			if (temperatur < 10) {
				System.out.println("Heute ist es ziemlich kalt. " + "Es hat " + temperatur + " Grad. Ziehen Sie eine Jacke an.");
			}			
			else { 
				if (temperatur <= 17) {
					System.out.println("Erw�gen Sie ein T-Shirt unter " + "den Pullover anzuziehen. Es hat heute " + temperatur
					+ " Grad.");
				}
				else {
					if (temperatur <= 25) {
						System.out.println("Ziehen Sie sich heute nicht " + "zu warm an. Das erledigt das Wetter mit " + temperatur
						+ " Grad.");
					}			
					else {
						System.out.println("Machen Sie heute frei und " + "gehen Sie zum Baden. Es ist heute mit " + temperatur
						+ " Grad sehr warm.");
					}
				}
			}
		}
	}
}
