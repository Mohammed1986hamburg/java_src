package oca.kontrollstrukturen.uebungen;

import java.util.Arrays;

public class _6UnterschiedlicheLottoZahlen {

	public static void main(String[] args) {
	
	// --------------------------  Ohne Array -----------------------------
		int a,b,c,d,e,f; 
 
			a = (int)(Math.random() * 49+1); 
			b = (int)(Math.random() * 49+1);
			c = (int)(Math.random() * 49+1); 
			d = (int)(Math.random() * 49+1); 
			e = (int)(Math.random() * 49+1); 
			f = (int)(Math.random() * 49+1); 
  
		
		System.out.println(a+" "+b+" "+c+" "+d+" "+e+" "+f); 
		
		
	// --------------------------  Mit Array --------------------------------
		
		int [] lottoZahlen = new int [6]; 			// fasst 6 Werte mit einer Indexierung von 0 - 5
		
		for (int i = 0 ; i < lottoZahlen.length ; i++) {
			for (int j = 0 ; j< lottoZahlen.length;j++) {
				for (int k = 0 ; k< lottoZahlen.length;k++) {
					for (int l = 0 ; l< lottoZahlen.length;l++) {
						for (int m = 0 ; m< lottoZahlen.length;m++) {
							for (int n = 0 ; n< lottoZahlen.length;n++) {
								if (lottoZahlen[i] == lottoZahlen[j] ||
									lottoZahlen[i] == lottoZahlen[k] ||
									lottoZahlen[i] == lottoZahlen[l] ||
									lottoZahlen[i] == lottoZahlen[m] ||
									lottoZahlen[i] == lottoZahlen[n] ||
										lottoZahlen[j] == lottoZahlen[k] ||
										lottoZahlen[j] == lottoZahlen[l] ||
										lottoZahlen[j] == lottoZahlen[m] ||
										lottoZahlen[j] == lottoZahlen[n] ||
											lottoZahlen[k] == lottoZahlen[l] ||
											lottoZahlen[k] == lottoZahlen[m] ||
											lottoZahlen[k] == lottoZahlen[n] ||
												lottoZahlen[l] == lottoZahlen[m] ||
												lottoZahlen[l] == lottoZahlen[n] ) {
															lottoZahlen[i] = (int)(Math.random() * 49+1); 																		
									}
							}
						}
					}
				}
			}
		}

		System.out.println(Arrays.toString(lottoZahlen));
 }
}

