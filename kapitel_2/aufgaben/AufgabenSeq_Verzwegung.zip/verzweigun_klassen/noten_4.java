package oca.kontrollstrukturen.uebungen;
import java.util.Scanner;
//Aufgabe 11
public class noten_4{
	
	public static void main(String[] args) {
		
		String[] notenString	= {"sehr gut","gut","befriedigend","ausreichend","mangelhaft","unbefriedigend"};
		
		Scanner input			= new Scanner(System.in);
		//String inputString;
		int noten;
		
		System.out.print("Bitte geben Sie eine Note ein: ");
		//inputString				= input.nextLine();
		//noten					= Integer.parseInt(inputString);
		noten					= input.nextInt();
		if(noten < 1 || noten > 6) {
			System.out.println("keine g�ltige Note");
		}
		if(noten >= 1 && noten <= 6) {
			System.out.println(notenString[noten-1]);
		}
		
		input.close();
	}
}